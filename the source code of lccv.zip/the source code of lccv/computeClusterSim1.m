function [ sim ] =computeClusterSim1( cdata,conn,cluster_number,nc)
%������Ի����Ⱥͽӽ��ȼ���ؼ����ƶ�
sim=zeros(cluster_number,cluster_number);
for i=1:cluster_number
    for j=i+1:cluster_number
        ncutedge=0;
        sumcutedge=0;
        for k=1:nc(i)
            for m=1:nc(j)
                if conn(cdata{1,i}(1,k),cdata{1,j}(1,m))~=0
                    ncutedge=ncutedge+1;
                    sumcutedge=sumcutedge+conn(cdata{1,i}(1,k),cdata{1,j}(1,m));
                end
            end
        end
        if ncutedge~=0
        ave=sumcutedge/ncutedge;
        sim(i,j)=ave^3*ncutedge;
        sim(j,i)=sim(i,j);
        end
    end
end


end

