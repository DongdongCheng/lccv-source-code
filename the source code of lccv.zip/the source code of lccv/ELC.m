% -------------------------------------------------------------------------
%Aim: Use the LCCV index and other clustering algorithms to determine the
%     best clustering results
% -------------------------------------------------------------------------
%Input:
%A: the data set
% -------------------------------------------------------------------------
%Output:
%%results: the clustering results
%bestcl: the best clustering results
% -------------------------------------------------------------------------
% Written by Dongdong Cheng
% Department of Computer Science, Chongqing University 
% December 2016
function [bestcl ] = ELC( A )
[N,dim]=size(A);
%Compute the Euclidean distance between points
dist=zeros(N,N);
    for i=1:N
        for j=1:N
            for k=1:dim
            dist(i,j)=dist(i,j)+(A(i,k)-A(j,k))^2;
            end
            dist(i,j)=sqrt(dist(i,j));
        end
    end
[sdist,index]=sort(dist,2);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%NaN-Searching algorithm
fprintf('Start running NaN-Searching algorithm...\n');
r=1;
flag=0;         
nb=zeros(1,N);  %The number of each point's reverse neighbor
count=0;        
count1=0;    
while flag==0
    for i=1:N
        k=index(i,r+1);
        nb(k)=nb(k)+1;
       RNN(k,nb(k))=i;
    end
    r=r+1;
    count2=0;
    for i=1:N
        if nb(i)==0
            count2=count2+1;
        end
    end
    if count1==count2
        count=count+1;
    else
        count=1;
    end
    if count2==0 || (r>2 && count>=2)   %The terminal condition
        flag=1;
    end
    count1=count2;
end

supk=r-1;               %The characteristic value of natural neighbor
max_nb=max(nb);         %The maximum value of nb
fprintf('The characteristic value is %d\n',supk);
fprintf('The maximum value of nb is %d\n',max_nb);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Calculate the density of each point
rho=zeros(N,1);
Non=max_nb;
for i=1:N
    d=0;
    for j=1:Non+1
        d=d+sdist(i,j);
    end
    rho(i)=(Non/d);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[rho_sorted,ordrho]=sort(rho,'descend');%sort the points according to the density
local_core=zeros(N,1);%the representative of each point
fprintf('Start running LORE algorithm...\n');
for i=1:N
         p=ordrho(i);
         maxrho=rho(p);
         maxindex=p;
         %Find the point with maximum density in the local neighbors
         for j=1:nb(p)+1
             x=index(p,j);
             if maxrho<rho(x)
                 maxrho=rho(x);
                 maxindex=x;
             end
         end
         %Assign representative of the point with maximum density
         if local_core(maxindex)==0
             local_core(maxindex)=maxindex;            
         end
         %Assign representative of the local neighbors
         for j=1:nb(p)+1
             if local_core(index(p,j))==0
                 local_core(index(p,j))=local_core(maxindex);
             else%Determine the representative according to RCR
                 q=local_core(index(p,j));
                 if dist(index(p,j),q)>dist(index(p,j),local_core(maxindex))% rho(q)<rho(local_core(maxindex))%
                     local_core(index(p,j))=local_core(maxindex);
                 end
             end 
             %Determine the representative according to RTR
             for m=1:N
                 if local_core(m)==index(p,j)
                     local_core(m)=local_core(index(p,j));
                 end
             end
         end
  
end
%Find the cores
 cluster_number=0;
 cl=zeros(N,1);
for i=1:N
    if local_core(i)==i;
       cluster_number=cluster_number+1;
       cores(cluster_number)=i;
       cl(i)=cluster_number;
    end
end
for i=1:N
    cl(i)=cl(local_core(i));
end
fprintf('The number of initial clusters is %d\n',cluster_number);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %�������ĵ�ͼ�Լ���Ӧ�ĳ�ʼ������
% plot(A(:,1),A(:,2),'.');
% hold on;
% for i=1:N
%     plot([A(i,1),A(local_core(i),1)],[A(i,2),A(local_core(i),2)]);
%     hold on;
% end
% % drawcluster2(A,cl,cluster_number+1);
% hold on;
% plot(A(local_core,1),A(local_core,2),'r*','MarkerSize',8);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Construct the graph
weight=zeros(N,N);
for i=1:N
%     if isnoise(i)==0
    for j=2:supk+1
        x=index(i,j);
        weight(i,x)=dist(i,x);
    end
%     end
end
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Compute the shortest path between cores
fprintf('Start computing the graph-based distance between local cores...\n');
short_path=zeros(cluster_number,cluster_number);%The shortest path between local cores
% maxd=(exp(alpha*maxd)-1)^(1/alpha);
weight2=sparse(weight);
fprintf('Start clustering...\n');
for i=1:cluster_number
     short_path(i,i)=0;
%      [D,Z]=dijkstra2(weight,cores(i));
      [D,~,Z] = graphshortestpath(weight2,cores(i),'METHOD','Dijkstra'); 
     for j=i+1:cluster_number
         short_path(i,j)=D(cores(j));
         if short_path(i,j)==inf
             short_path(i,j)=0;
         end
         short_path(j,i)=short_path(i,j);
     end
end
maxd=max(max(short_path));
for i=1:cluster_number
    for j=1:cluster_number;
        if short_path(i,j)==0;
            short_path(i,j)=maxd;
        end
    end
end
cv=zeros(cluster_number,1);
results=cell(cluster_number,2);
maxcv=0;
for nc=2:floor(sqrt(N))%50%cluster_number-1
% Use K-means algorithm to cluster
%     cl= k_means(A, 'random', nc);
%     cv(nc)=computeMySWC(A,cl,nc,cores,short_path,local_core);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Use DBSCAN algorithm to cluster
    [cl,~,~]=dbscan(A,nc); 
    for i=1:N
        if cl(i)~=-1&&cl(i)~=cl(local_core(i))
            cl(i)=cl(local_core(i));
        end
    end
    for i=1:max(cl)
        temp1=find(cl==i);
        if isempty(temp1)
            for j=i+1:max(cl)
            temp2=find(cl==j);
            if ~isempty(temp2)
            cl(temp2)=cl(temp2)-1;
            end
            end
        end
    end
    nl=max(cl);
    cv(nc)=computeMySWC(A,cl,nl,cores,short_path,local_core);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    results{nc,1}=cl;
    results{nc,2}=cv(nc);
    if maxcv<cv(nc)
        maxcv=cv(nc);
        bestcl=cl;
    end
end
fprintf('Process end\n');
end

