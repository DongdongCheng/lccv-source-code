# lccv-source-code
A novel cluster validity index based on local cores
