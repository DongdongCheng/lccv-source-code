% -------------------------------------------------------------------------
%Aim: compute the Silhouette index
% -------------------------------------------------------------------------
%Input:
%D: the dataset
%cl: the cluster label of each point
%ncl: the number of clusters
% -------------------------------------------------------------------------
%Output:
%swc: result the silhoutte width criterion (when using silhouette index)
%s1: the silhouette value of each point (when computing LCCV index)
% -------------------------------------------------------------------------
%Reference: Rousseeuw P. Silhouettes: A graphical aid to the interpretation
%           and validation of cluster analysis[J]. Journal of Computational
%           & Applied Mathematics, 1987, 20(20):53-65.
% -------------------------------------------------------------------------
% Written by Dongdong Cheng
% Department of Computer Science, Chongqing University 
% December 2016

function [ swc,s1] =computeSWC( D, cl,ncl,dist )

[n,d]=size(D);
    cdata=cell(1,ncl);% the number of points in each cluster
    numc=ncl;
    for i=1:ncl
        nump=0;
        for j=1:n
            if cl(j)==i
                nump=nump+1;
                cdata{1,i}(nump,:)=D(j,:);
                cindex(i,nump)=j;
            end
        end
    end
    numo=0;
    %Don't compute the swc of outliers
    if min(cl)<=0;
        for i=1:n
            if cl(i)<=0
                numo=numo+1;
            end
        end
    end
swc=0;
s1=zeros(n,1);
for i=1:numc
%     fprintf('��������%d\n',i);
    a=[];
    b=[];
    s=[];
    [np,~]=size(cdata{1,i});
    if np>1
    for j=1:np
        %compute a(j)
        suma=0;
        for k=1:np
            if j~=k
%                 suma=suma+pdist2(cdata{1,i}(j,:),cdata{1,i}(k,:));
               suma=suma+dist(cindex(i,j),cindex(i,k));
            end
        end
        a(j)=suma/(np-1);
%         if np>1
%         a(j)=suma/(np-1);
%         else
%             a(j)=0;
%         end
        
        %compute b(j)
         d=ones(1,numc)*inf;
        for k=1:numc
            if k~=i
                [np2,~]=size(cdata{1,k});
                sumd=0;
                for l=1:np2
%                     sumd=sumd+pdist2(cdata{1,i}(j,:),cdata{1,k}(l,:));
                    sumd=sumd+dist(cindex(i,j),cindex(k,l));
                end
                d(k)=sumd/np2;
            end
        end
        b(j)=min(d);
        %compute s(j)
        s(j)=(b(j)-a(j))/max(a(j),b(j));
        s1(cindex(i,j))=s(j);
%         fprintf('a(j)=%f,b(j)=%f,s(j)=%f\n',a(j),b(j),s(j));
        swc=swc+s(j); 
    end 
%     else
%         s1(cindex(i,1))=0;
    end
end
% % fprintf('swc=%f\n',swc);
swc=swc/(n-numo);

end

