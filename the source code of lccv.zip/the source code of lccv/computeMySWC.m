% -------------------------------------------------------------------------
%Aim: compute the LCCV index
% -------------------------------------------------------------------------
%Input:
%A: the data set
%cl: cluster label
%cores: the cores
%pdist: the length of shortest path between cores
%local_core: the representative of each point
% -------------------------------------------------------------------------
%Output:
%mcv: the lccv value 
% -------------------------------------------------------------------------
% Written by Dongdong Cheng
% Department of Computer Science, Chongqing University 
% December 2016
function mcv=computeMySWC(A,cl,ncl,cores,pdist,local_core)
[~,ncores]=size(cores);
[n,dim]=size(A);
D=zeros(ncores,dim);
cl_cores=zeros(ncores,1);
for i=1:ncores
    D(i,:)=A(cores(i),:);
    cl_cores(i)=cl(cores(i));
end
nl=zeros(ncores,1);
%Count the number of points belonging to each cores
for i=1:ncores
    for j=1:n
        if local_core(j)==cores(i)&&cl(j)>0
            nl(i)=nl(i)+1;
        end
    end
end
[~,s]=computeSWC( D, cl_cores,ncl,pdist );
mcv=0;
for i=1:ncores
    mcv=mcv+s(i)*nl(i);
%     mcv=mcv+s(i);
%     if nl(i)>4
%     mcv=mcv+s(i);
%     k=k+1;
%     end
end
mcv=mcv/n;
end

