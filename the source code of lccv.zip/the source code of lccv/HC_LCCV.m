% -------------------------------------------------------------------------
%Aim:
%The matlab code of "A novel cluster validity index based on local cores"
% -------------------------------------------------------------------------
%Input:
%A: the data set
% -------------------------------------------------------------------------
%Output:
%results: the clustering results
%bestcl: the best clustering results 
%time: the running time
% -------------------------------------------------------------------------
% Written by Dongdong Cheng
% Department of Computer Science, Chongqing University 
% December 2016
function [bestcl] = HC_LCCV(A)
tic;
%Compute the Euclidean distance between points
[N,dim]=size(A);
dist=zeros(N,N);
    for i=1:N
        for j=1:N
            for k=1:dim
            dist(i,j)=dist(i,j)+(A(i,k)-A(j,k))^2;
            end
            dist(i,j)=sqrt(dist(i,j));
        end
    end
[sdist,index]=sort(dist,2);%Sort the distances
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%NaN-Searching algorithm
fprintf('Start running NaN-Searching algorithm...\n');
r=1;
flag=0;         
nb=zeros(1,N);  %The number of each point's reverse neighbor
count=0;        
count1=0;    
while flag==0
    for i=1:N
        k=index(i,r+1);
        nb(k)=nb(k)+1;
       RNN(k,nb(k))=i;
    end
    r=r+1;
    count2=0;
    for i=1:N
        if nb(i)==0
            count2=count2+1;
        end
    end
    if count1==count2
        count=count+1;
    else
        count=1;
    end
    if count2==0 || (r>2 && count>=2)   %The terminal condition
        flag=1;
    end
    count1=count2;
end

supk=r-1;               %The characteristic value of natural neighbor
max_nb=max(nb);         %The maximum value of nb
fprintf('The characteristic value is %d\n',supk);
fprintf('The maximum value of nb is %d\n',max_nb);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Calculate the density of each point
rho=zeros(N,1);
Non=max_nb;
for i=1:N
    d=0;
    for j=1:Non+1
        d=d+sdist(i,j);
    end
    rho(i)=(Non/d);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%LORE Algorithm
[rho_sorted,ordrho]=sort(rho,'descend');%sort the points according to the density
local_core=zeros(N,1);%The representative of each point
fprintf('Starting running LORE algorithm...\n');
for i=1:N
         p=ordrho(i);
         maxrho=rho(p);
         maxindex=p;
         %Find the point with maximum density in the local neighbors
         for j=1:nb(p)+1
             x=index(p,j);
             if maxrho<rho(x)
                 maxrho=rho(x);
                 maxindex=x;
             end
         end
         %Assign representative of the point with maximum density
         if local_core(maxindex)==0
             local_core(maxindex)=maxindex;            
         end
         %Assign representative of the local neighbors
         for j=1:nb(p)+1
             if local_core(index(p,j))==0
                 local_core(index(p,j))=local_core(maxindex);
             else%Determine the representative according to RCR
                 q=local_core(index(p,j));
                 if dist(index(p,j),q)>dist(index(p,j),local_core(maxindex))% rho(q)<rho(local_core(maxindex))%
                     local_core(index(p,j))=local_core(maxindex);
                 end
             end 
             %Determine the representative according to RTR
             for m=1:N
                 if local_core(m)==index(p,j)
                     local_core(m)=local_core(index(p,j));
                 end
             end
         end
  
end
%Find the cores
 cluster_number=0;
 cl=zeros(N,1);
for i=1:N
    if local_core(i)==i;
       cluster_number=cluster_number+1;
       cores(cluster_number)=i;
       cl(i)=cluster_number;
    end
end
for i=1:N
    cl(i)=cl(local_core(i));
end
fprintf('The number of initial clusters is %d\n',cluster_number);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %Draw the cores and initial cluster result
% plot(A(:,1),A(:,2),'.');
% hold on;
% for i=1:N
%     plot([A(i,1),A(local_core(i),1)],[A(i,2),A(local_core(i),2)]);
%     hold on;
% end
% drawcluster2(A,cl,cluster_number+1);
% hold on;
% plot(A(local_core,1),A(local_core,2),'r*','MarkerSize',8);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Construct the graph
conn=zeros(N,N);
weight=zeros(N,N);
for i=1:N
%     if isnoise(i)==0
    for j=2:supk+1
        x=index(i,j);
        conn(i,x)=1/(1+dist(i,x));%����ĵ�����Ϊ��������ƶ�
        conn(x,i)=conn(i,x);
        weight(i,x)=dist(i,x);
    end
%     end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Compute the shortest path
fprintf('Start computing the graph-based distance between local cores...\n');
short_path=zeros(cluster_number,cluster_number);%The shortest path between local cores
weight2=sparse(weight);
for i=1:cluster_number
     short_path(i,i)=0; 
    [D,~,Z] = graphshortestpath(weight2,cores(i),'METHOD','Dijkstra'); 
%      [D,Z]=dijkstra2(weight,cores(i));
     for j=i+1:cluster_number
         short_path(i,j)=D(cores(j));
         if short_path(i,j)==inf
             short_path(i,j)=0;
         end
         short_path(j,i)=short_path(i,j);
     end
end
maxd=max(max(short_path));
for i=1:cluster_number
    for j=1:cluster_number;
        if short_path(i,j)==0;
            short_path(i,j)=maxd;
        end
    end
end
results=cell(cluster_number-1,4);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Compute the similarity between clusters
cdata=cell(1,cluster_number);%The points in each cluster
nc=zeros(1,cluster_number);%The points number in each cluster
    for i=1:cluster_number
        nc(i)=0;
       for j=1:N
           if cl(j)==i
               nc(i)=nc(i)+1;
               cdata{1,i}(1,nc(i))=j;
           end
       end
    end 
%Compute the similarity matrix
sim=computeClusterSim1(cdata,conn,cluster_number,nc);
results{1,1}=cdata;
results{1,2}=cl;
% results{1,3}=sim;
% results{1,4}=mcv;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Merge the small clusters
small_threshold=N/(cluster_number);
clunum2=cluster_number;
for i=1:cluster_number
    if nc(i)<=small_threshold
        v=0;ic=0;
       for j=1:cluster_number
           if sim(i,j)>v
               ic=j;
               v=sim(i,j);
           end
       end
       %If there are no clusters connecting the small clusters, the small clusters are considered as outliers
       if ic==0&&nc(i)<small_threshold/2
           for j=1:nc(i)
               x=cdata{1,i}(1,j);
%                isnoise(x)=1;
               cl(x)=0;
           end
           cdata{1,i}=[];
           nc(i)=0;
           clunum2=clunum2-1;
       end
       
   if ic>0
        clunum2=clunum2-1;
       %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
       %Merge the clusters
       for j=1:nc(i)
        cdata{1,ic}(1,nc(ic)+j)=cdata{1,i}(1,j);
       end
        nc(ic)=nc(ic)+nc(i);
         ncand=0;
        for k=1:cluster_number
           if k~=ic&&k~=i
               if sim(ic,k)~=0||sim(i,k)~=0
                   ncand=ncand+1;
                   canClu(ncand)=k;
               end
           end
        end
       %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
       %Update the similarity matrix
       for j=1:ncand
           ncutedge=0;
           sumcutedge=0;
           if canClu(j)~=ic&&canClu(j)~=i
             for k=1:nc(ic)
                for m=1:nc(canClu(j))
                   if conn(cdata{1,ic}(1,k),cdata{1,canClu(j)}(1,m))~=0
                     ncutedge=ncutedge+1;
                     sumcutedge=sumcutedge+conn(cdata{1,ic}(1,k),cdata{1,canClu(j)}(1,m));
                   end
                end           
             end
           end
         if ncutedge~=0
              ave=sumcutedge/ncutedge;
              sim(ic,canClu(j))=ave^3*ncutedge;
              sim(canClu(j),ic)=sim(ic,canClu(j));
         end   
       end
       sim(i,:)=0;
       sim(:,i)=0;
       nc(i)=0;
       cdata{1,i}=[];
       %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      end
    end 
end
%     Obtain the clustering result after merging small clusters
     for i=1:cluster_number
         cl(cdata{1,i})=i;
     end
     for i=1:cluster_number
         if nc(i)==0
             for j=i+1:cluster_number
                 cl(cdata{1,j})=cl(cdata{1,j})-1;
             end
         end
     end                 
    mcv=computeMySWC(A,cl,clunum2,cores,short_path,local_core);
    results{cluster_number-clunum2+1,1}=cdata;
    results{cluster_number-clunum2+1,3}=sim;
    results{cluster_number-clunum2+1,2}=cl;
    results{cluster_number-clunum2+1,4}(1,1)=mcv;
    results{cluster_number-clunum2+1,4}(1,2)=clunum2;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Merge clusters and Obtain the best clustering result
fprintf('Start merging clusters...\n');
clunum=clunum2;
% fprintf('The number of clusters��%d\n',clunum);
while clunum>2
%     fprintf('The number of cluster is %d\n',clunum);
    %Store the results
    results{cluster_number-clunum+1,1}=cdata;
    results{cluster_number-clunum+1,3}=sim;
    results{cluster_number-clunum+1,2}=cl;
    results{cluster_number-clunum+1,4}(1,1)=mcv;
    results{cluster_number-clunum+1,4}(1,2)=clunum;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %Find two clusters with the biggest similarity
    maxsim=0;
    idx=-1;
    idy=idx;
    for i=1:cluster_number
        for j=1:cluster_number
            if sim(i,j)>maxsim
                maxsim=sim(i,j);
                idx=i;
                idy=j;
            end
        end
    end
    %�洢Ҫ�ϲ���������
     results{cluster_number-clunum+1,5}=[idx,idy];
%      fprintf('In %d times merging,to be merged clusters are:%d, %d\n', cluster_number-clunum+1,idx,idy);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      %Merge the clusters
    if idx~=idy%������ںϲ��Ĵؾͽ��кϲ�
        if idx>idy
           t=idx;
           idx=idy;
           idy=t;      
        end
       
       for i=1:nc(idy)
          cdata{1,idx}(1,nc(idx)+i)=cdata{1,idy}(1,i);
       end
       nc(idx)=nc(idx)+nc(idy);
       cdata{1,idy}=[];%��ʾ�ô��������Ĵؽ����˺ϲ����ôز�������
       nc(idy)=0;
       clunum=clunum-1;
      %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      %Update the similarity matrix
       ncand=0;
       for i=1:cluster_number
           if i~=idx&&i~=idy
               if sim(idx,i)~=0||sim(idy,i)~=0
                   ncand=ncand+1;
                   canditateClu(ncand)=i;
               end
           end
       end
       for j=1:ncand
           ncutedge=0;
           sumcutedge=0;
           if canditateClu(j)~=idx&&canditateClu(j)~=idy
             for i=1:nc(idx)
                for m=1:nc(canditateClu(j))
                   if conn(cdata{1,idx}(1,i),cdata{1,canditateClu(j)}(1,m))~=0
                     ncutedge=ncutedge+1;
                     sumcutedge=sumcutedge+conn(cdata{1,idx}(1,i),cdata{1,canditateClu(j)}(1,m));
                   end
                end           
             end
           end
         if ncutedge~=0
              ave=sumcutedge/ncutedge;
              sim(idx,canditateClu(j))=ave^3*ncutedge;
              sim(canditateClu(j),idx)=sim(idx,canditateClu(j));
         end   
       end

       sim(idy,:)=0;
       sim(:,idy)=0;
      %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
%      Obtain the clustering result
     for i=1:cluster_number
         cl(cdata{1,i})=i;
     end
     for i=1:cluster_number
         if nc(i)==0
             for j=i+1:cluster_number
                 cl(cdata{1,j})=cl(cdata{1,j})-1;
             end
         end
     end                 
      mcv=computeMySWC(A,cl,clunum,cores,short_path,local_core);
     if clunum==2%���һ�κϲ���Ľ��
%          fprintf('The last time merge\n');
          results{cluster_number-clunum+1,1}=cdata;
          results{cluster_number-clunum+1,3}=sim;
          results{cluster_number-clunum+1,2}=cl;
          results{cluster_number-clunum+1,4}=mcv;
          results{cluster_number-clunum+1,4}(1,2)=clunum;
     end
    else %If there are no clusters to be merged, terminate the while-loop
        results{cluster_number-1,1}=[];
        results{cluster_number-1,2}=[];
        results{cluster_number-1,3}=[];
        results{cluster_number-1,4}=[];
%        fprintf('There are no clusters to be merged\n');
        break;
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Obtain the best clustering result from a serise of results
for i=1:cluster_number-1
    [a,b]=size(results{i,4});
    if a~=0
       cv(i)=results{i,4}(1,1);
    else
        cv(i)=-inf;
    end
end
[~,id]=max(cv);
bestcl=results{id,2};
% ncl=results{id,4}(2);
time=toc;
fprintf('Process end\n');
end

