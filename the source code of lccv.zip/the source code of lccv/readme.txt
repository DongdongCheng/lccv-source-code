# lccv-source-code
A novel cluster validity index based on local cores

In "the source code of lccv", file HC_LCCV includes Algorithm 1 and Algorithm 2, and file ELC includes Algorithm 3. File Datasets include all the synthetic data sets used in the experiment of this paper "A novel cluster validity index based on local cores".
